
from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileRequired, FileAllowed
from sqlalchemy import Column, Integer, String, ForeignKey
from sqlalchemy import create_engine, or_
engine = create_engine('sqlite:///kinases2.db', echo = True)
from sqlalchemy.ext.declarative import declarative_base
Base = declarative_base()
from sqlalchemy.orm import sessionmaker, relationship
Session = sessionmaker(bind = engine)
session = Session()
from flask import Flask, flash, render_template, request, redirect, url_for, jsonify
from wtforms import StringField, SelectField, SubmitField
from wtforms.validators import DataRequired
from werkzeug.utils import secure_filename
import pandas as pd
import os
import re

#-------------------------------------------------------------------------------------------------------------------------- 
#Flask application object
application = Flask(__name__)
application.config['SECRET_KEY'] = 'jacky'

UPLOAD_FOLDER =  os.path.dirname(os.path.abspath(__file__)) + '/uploads/'
application.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
#app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

#-------------------------------------------------------------------------------------------------------------------------- 

#Search & Upload File forms
#--------------------------------------------------------------------------------------------------------------------------  
class SearchForm(FlaskForm):
    protein_name = StringField("", validators=[DataRequired()])
    submit = SubmitField('Submit')
#--------------------------------------------------------------------------------------------------------------------------  

#Setting database structure
#--------------------------------------------------------------------------------------------------------------------------  
class HumanKinases(Base):
    __tablename__ = 'human_kinases'
    UniProt_ID = Column(String(15), primary_key=True)
    PDB_ID = Column(String(5))
    PDB_URL = Column(String(60))
    PDB_title = Column(String(250))
    Entry_name = Column(String(15))
    Primary_Protein_Name = Column (String(100))
    Alternative_Protein_Name = Column(String(350)) 
    Gene_Symbol = Column(String(15))
    Alternative_Gene_Name = Column(String(60)) 
    Families = Column(String(175))
    AA_Seq = Column(String(34400))
    Molecular_Mass = Column(String(10))
    Subcellular_Location = Column(String(350))

class Phosphosites(Base):
    __tablename__ = 'phosphosites'
    GENE = Column(String(20))
    PROTEIN = Column(String(20))
    ACC_ID = Column(String(19))
    HU_CHR_LOC = Column(String(26))
    MOD_RSD = Column(String(6))
    SITE_GRP_ID = Column(String(10))
    MW_kD = Column(Integer)
    DOMAIN = Column(String(30)) 
    SITE_7_AA = Column(String(15))
    LT_LIT = Column(Integer)
    MS_LIT = Column(Integer)
    MS_CST = Column(Integer)
    CST_CAT = Column(String(141))
    PHOS_ID = Column(String(31))
    PHOS_ID2 = Column(String(26))
    PHOS_ID3 = Column(String(32))
    PHOS_ID4 = Column(String(25))
    PHOS_ID5 = Column(String(24), primary_key=True)
    SOURCE = Column (String(66))
    SEQUENCE = Column(String(3500)) # NOT INCLUDED THE LENGTH IN THE FILE
    PMID = Column(String(8))
    ISOFORM = Column(Integer)
    ID_PH = Column(String(9))

class Inhibitors(Base):
    __tablename__ = 'inhibitors'
    Inhibitor = Column (String(150), primary_key=True)
    Ki_nM = Column (Integer) # does entry n/a affect?
    IC50_nM = Column (Integer) # does entry n/a affect?
    Kd_nM = Column (Integer) # does entry n/a affect?
    EC50_nM = Column (Integer) # does entry n/a affect?
    POC = Column (Integer) # does entry n/a affect?
    Source = Column (String(15))
    IMG_URL = Column (String(100))
    ID_IN = Column (String(10))

class KinasesPhosphosites(Base):
    __tablename__ = 'kinases_phosphosites'
    GENE = Column(String(13))
    KIN_ACC_ID = Column (String(9), ForeignKey('human_kinases.UniProt_ID') )
    SUB_ACC_ID = Column (String(17))
    IN_VIVO_RXN = Column(String(1))
    IN_VITRO_RXN = Column(String(1))
    CST_CAT = Column(String(141))
    PHOS_ID = Column(String(31)) # ForeignKey('phosphosites.PHOS_ID5'))
    PHOS_ID2 = Column(String(23))
    PHOS_ID3 = Column(String(29))
    PHOS_ID4 = Column(String(25))
    PHOS_ID5 = Column(String(23), ForeignKey('phosphosites.PHOS_ID5'))
    SOURCE = Column (String(64))
    SEQUENCE = Column (String(8797))
    PMID = Column (String(8))
    #KIN_ACC_ID_2 = Column(String(10), ForeignKey('human_kinases.UniProt_ID'))
    ID_KS = Column(String(9), primary_key=True)

class PhosphositesDiseases(Base):
    __tablename__ = 'phosphosites_diseases'
    DISEASE = Column(String(92))
    ALTERATION = Column(String(32)) # sometimes multiples separated by ";" ERROR in sql
    ACC_ID = Column(String(16))
    PMIDs = Column(String(8))
    LT_LIT = Column(Integer)
    MS_LIT = Column(Integer)
    MS_CST = Column(Integer)
    CST_CAT = Column(String(141)) # sometimes multiples separated by ";" ERROR in sql
    NOTES = Column(String(314))
    PHOS_ID = Column(String(22), ForeignKey('phosphosites.PHOS_ID5'))  # duplicates
    ID_PD = Column(String(9), primary_key=True)

class InhibKin(Base):
    __tablename__ = 'inhib_kin'
    Kinase = Column(String(30)) #ForeignKey('human_kinases.Entry_name')) 
    Inhibitor = Column (String(150), ForeignKey('inhibitors.Inhibitor'))
    ID_KI = Column (String(10), primary_key=True)
    UniProt_ID = Column(String(6), ForeignKey('human_kinases.UniProt_ID'))

kinases_phosphosites = relationship("KinasesPhosphosites", backref="human_kinases")
inhibitors_kinases = relationship("Inhibitors", backref="human_kinases")

phosphosites_kinases = relationship("KinasesPhosphosites", backref="phosphosites")
phosphosites_diseases = relationship("PhosphositesDiseases", backref="phosphosites")

inhib_kin = relationship("InhibKin", backref="inhibitors")


Base.metadata.create_all(engine)
#--------------------------------------------------------------------------------------------------------------------------  



#Main application script

#Homepage(s)
#--------------------------------------------------------------------------------------------------------------------------  
#init_db()

@application.route('/', methods=['GET', 'POST'])
#@app.route('/datanalysis', methods = ['GET', 'POST'])
@application.route('/home') 
def index():
    form = SearchForm()
    #form1 = DocumentUploadForm()
    if request.method == 'POST':
        file = request.files['file']
        filename = secure_filename(file.filename)
        file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))



        return redirect('/')
    return render_template('homepage.html', form=form)

@application.route('/kin/', methods=['GET', 'POST']) 
def kin():
    form = SearchForm()
    protein_name = None
    if form.validate_on_submit():
        protein_name = form.protein_name.data
        return redirect(url_for('kinasesearch', kinase_search=protein_name))
    return render_template('homepagekin.html', form=form)

@application.route('/inh/', methods=['GET', 'POST']) 
def inh():
    form = SearchForm()
    protein_name = None
    if form.validate_on_submit():
        protein_name = form.protein_name.data
        return redirect(url_for('inhibitorsearch', inhibitor_search=protein_name))
    return render_template('homepageinh.html',form=form)

@application.route('/phos/', methods=['GET', 'POST']) #If Phosphosite selected on select search menu, redirects to homepage with an additional select box (genomic location & neighbouring sequence)
def phos():
    form = SearchForm()
    #protein_name = None
    return render_template('homepagephos.html', form=form)

@application.route('/nseq/', methods=['GET', 'POST']) #If Phosphosite selected on select search menu, redirects to homepage with an additional select box (genomic location & neighbouring sequence)
def phosnseq():
    form = SearchForm()
    protein_name = None
    if form.validate_on_submit():
        protein_name = form.protein_name.data
        return redirect(url_for('phosphositesearchnseq', phosphosite_search=protein_name))
    return render_template('homepagephos.html', form=form)

@application.route('/prot/', methods=['GET', 'POST']) #If Phosphosite selected on select search menu, redirects to homepage with an additional select box (genomic location & neighbouring sequence)
def phosprot():
    form = SearchForm()
    protein_name = None
    if form.validate_on_submit():
        protein_name = form.protein_name.data
        return redirect(url_for('phosphositesearchprot', phosphosite_search=protein_name))
    return render_template('homepagephos.html', form=form)

@application.route('/phoskin/', methods=['GET', 'POST']) #If Phosphosite selected on select search menu, redirects to homepage with an additional select box (genomic location & neighbouring sequence)
def phospkin():
    form = SearchForm()
    protein_name = None
    if form.validate_on_submit():
        protein_name = form.protein_name.data
        return redirect(url_for('phosphositesearchkin', phosphosite_search=protein_name))
    return render_template('homepagephos.html', form=form)



#The next routes are to redirect to the intended url
@application.route('/kin/inh/')
@application.route('/phos/inh/')
@application.route('/prot/inh/')
@application.route('/gen/inh/')
@application.route('/nseq/inh/')
@application.route('/phos/redirect/inh/')
@application.route('/kin/redirect/inh/')
def redihn():
    return redirect('/inh/')

@application.route('/inh/phos/')
@application.route('/kin/phos/')
@application.route('/inh/redirect/phos/')
@application.route('/kin/redirect/phos/')
def redphos():
    return redirect('/phos/')

@application.route('/inh/kin/')
@application.route('/phos/kin/')
@application.route('/phoskin/kin/')
@application.route('/prot/kin/')
@application.route('/gen/kin/')
@application.route('/nseq/kin/')
@application.route('/inh/redirect/kin/')
@application.route('/phos/redirect/kin/')
def redkin():
    return redirect('/kin/')

@application.route('/prot/nseq')
@application.route('/gen/nseq')
def rednseq():
    return redirect('/nseq/')

@application.route('/nseq/prot')
@application.route('/gen/prot')
def redprot():
    return redirect('/prot/')

@application.route('/nseq/gen')
@application.route('/prot/gen')
def redgen():
    return redirect('/gen/')


#------------------------------------------------------------------------------------------------------------------------------------------   

#Data analysis page
#-----------------------------------------------------------------------------------------------------------------------------------------------------
#@app.route('/datanalysis', methods = ['GET', 'POST'])
#def datanalysis():
    #return render_template('datanalysis.html')
#---------------------------------------------------------------------------------------------------------------------------------------------------- 

#Hits pages
#------------------------------------------------------------------------------------------------------------------------------------------
#Inhibitor search results page
@application.route('/inh/<inhibitor_search>', methods=['GET', 'POST'])
def inhibitorsearch(inhibitor_search):
    form = SearchForm()
    inhibitor_search = inhibitor_search.upper()
    resultss = session.query(Inhibitors).filter(Inhibitors.Inhibitor.startswith(inhibitor_search)).all()
    protein_name = None
    if form.validate_on_submit():
        protein_name = form.protein_name.data
        return redirect(url_for('inhibitorsearch', inhibitor_search=protein_name))
    return render_template('inhibitorhits.html', resultss=resultss, form=form)

#Kinase search results page
@application.route('/kin/<kinase_search>', methods=['GET', 'POST'])
def kinasesearch(kinase_search):
    form = SearchForm()
    kinase_search = kinase_search.upper()
    resultss = session.query(HumanKinases).filter(or_(HumanKinases.Entry_name.startswith(kinase_search), HumanKinases.Gene_Symbol.startswith(kinase_search)) ).all()
    protein_name = None
    if form.validate_on_submit():
        protein_name = form.protein_name.data
        return redirect(url_for('kinasesearch', kinase_search=protein_name))
    return render_template('kinasehits.html', resultss=resultss, form=form)
 
#Phosphosite search by neighbouring sequence results page   
@application.route('/nseq/<phosphosite_search>', methods=['GET', 'POST'])
def phosphositesearchnseq(phosphosite_search):
    form = SearchForm()
    resultss = session.query(Phosphosites).join(KinasesPhosphosites).join(HumanKinases).filter(Phosphosites.SITE_7_AA.startswith(phosphosite_search)).all()
    protein_name = None
    if form.validate_on_submit():
        protein_name = form.protein_name.data
        return redirect(url_for('phosphositesearchnseq', phosphosite_search=protein_name))
    return render_template('phoshits.html', resultss=resultss, form=forpho)

#Phosphosite search by protein results page
@application.route('/prot/<phosphosite_search>', methods=['GET', 'POST'])
def phosphositesearchprot(phosphosite_search):
    form = SearchForm()
    resultss = session.query(Phosphosites).join(KinasesPhosphosites).join(HumanKinases).filter(Phosphosites.PROTEIN.startswith(phosphosite_search)).all()
    protein_name = None
    if form.validate_on_submit():
        protein_name = form.protein_name.data
        return redirect(url_for('phosphositesearchprot', phosphosite_search=protein_name))
    return render_template('phoshits.html', resultss=resultss, form=form)

#Phosphosite search by 'which kinase they're phosphorylated by' results page
@application.route('/phoskin/<phosphosite_search>', methods=['GET', 'POST'])
def phosphositesearchkin(phosphosite_search):
    form = SearchForm()
    resultss = session.query(Phosphosites).join(KinasesPhosphosites).join(HumanKinases).filter(HumanKinases.Entry_name.startswith(phosphosite_search)).all()
    protein_name = None
    if form.validate_on_submit():
        protein_name = form.protein_name.data
        return redirect(url_for('phosphositesearchkin', phosphosite_search=protein_name))
    return render_template('phoshits.html', resultss=resultss, form=form, )

#Phosphosite browse by genomic location page
@application.route('/gen/', methods=['GET', 'POST'])
def phosphositesearchgenhome():
    form = SearchForm()
    resultss = session.query(Phosphosites).filter(Phosphosites.HU_CHR_LOC.startswith('t')).all()
    if form.validate_on_submit():
        protein_name = form.protein_name.data
        return redirect(url_for('phosphositesearchgen', gen_location=protein_name))
    return render_template('zphoshitsgen.html',form=form, resultss=resultss)

#Phosphosite browse by genomic location page, once you have selected a genomic location
@application.route('/gen/<gen_location>', methods=['GET', 'POST'])
def phosphositesearchgen(gen_location):
    form = SearchForm()
    resultss = session.query(Phosphosites).filter(Phosphosites.HU_CHR_LOC.startswith(gen_location)).all()
    protein_name = None
    if form.validate_on_submit():
        protein_name = form.protein_name.data
        gen_location=protein_name
        #return redirect(url_for('phosphositesearchgen', gen_location=protein_name))
        if gen_location== '1':
            p= session.query(Phosphosites).filter(Phosphosites.HU_CHR_LOC.startswith('1p')).all()
            q= session.query(Phosphosites).filter(Phosphosites.HU_CHR_LOC.startswith('1q')).all()
            return render_template('zphoshitsgenalt.html',form=form, p=p, q=q)
        if gen_location== '2':
            p2= session.query(Phosphosites).filter(Phosphosites.HU_CHR_LOC.startswith('2p')).all()
            q2= session.query(Phosphosites).filter(Phosphosites.HU_CHR_LOC.startswith('2q')).all()
            return render_template('zphoshitsgenalt.html',form=form, q=q2, p=p2)
        else:
            return render_template('zphoshitsgen.html',form=form, resultss=resultss)
    else:
        if gen_location== '1':
            p= session.query(Phosphosites).filter(Phosphosites.HU_CHR_LOC.startswith('1p')).all()
            q= session.query(Phosphosites).filter(Phosphosites.HU_CHR_LOC.startswith('1q')).all()
            return render_template('zphoshitsgenalt.html',form=form, p=p, q=q)
        if gen_location== '2':
            p2= session.query(Phosphosites).filter(Phosphosites.HU_CHR_LOC.startswith('2p')).all()
            q2= session.query(Phosphosites).filter(Phosphosites.HU_CHR_LOC.startswith('2q')).all()
            return render_template('zphoshitsgenalt.html',form=form, q=q2, p=p2)
        else:
            return render_template('zphoshitsgen.html',form=form, resultss=resultss)
    return render_template('zphoshitsgen.html',form=form, resultss=resultss)
#--------------------------------------------------------------------------------------------------------------------------  


#Kinase, Phosphosite and Inhibitor information pages
#------------------------------------------------------------------------------------------------------------------------------------------

#Kinase page
@application.route('/kin/redirect/<kinase_name>', methods=['GET', 'POST'])
def kinase(kinase_name):
    form = SearchForm()
    searchkin = session.query(HumanKinases).filter(HumanKinases.Entry_name.startswith(kinase_name)).first()
    searchkinphos = session.query(Phosphosites).join(KinasesPhosphosites).join(HumanKinases).filter(HumanKinases.Entry_name==kinase_name).all()
    searchkininhibitors = session.query(Inhibitors).join(InhibKin).join(HumanKinases).filter(HumanKinases.Entry_name==kinase_name).all()
    protein_name = None
    if form.validate_on_submit():
        protein_name = form.protein_name.data
        return redirect(url_for('kinasesearch', kinase_search=protein_name))
    return render_template('kinasepage.html', kinase_name=kinase_name, UniProt_ID=searchkin.UniProt_ID, PDB_ID=searchkin.PDB_ID, PDB_URL=searchkin.PDB_URL, PDB_title=searchkin.PDB_title, Primary_Protein_Name=searchkin.Primary_Protein_Name, Alternate_Protein_Name=searchkin.Alternative_Protein_Name, Families=searchkin.Families, AA_sequence=searchkin.AA_Seq, Molecular_Mass=searchkin.Molecular_Mass, Subcellular_Location=searchkin.Subcellular_Location, Gene_Symbol=searchkin.Gene_Symbol, Alternative_Gene_Name=searchkin.Alternative_Gene_Name, searchkinphos=searchkinphos, searchkininhibitors=searchkininhibitors, form=form)

#Phosphosite page
@application.route('/phos/<phosphosite_search>/<phosphosite_name>', methods=['GET', 'POST'])
def phosphositepage(phosphosite_search, phosphosite_name):
    form = SearchForm()
    searchphos = session.query(Phosphosites).filter(Phosphosites.ID_PH==phosphosite_name).first()
    searchphoskin = session.query(HumanKinases).join(KinasesPhosphosites).join(Phosphosites).filter(Phosphosites.ID_PH==phosphosite_name).all()
    searchphosdis = session.query(PhosphositesDiseases).join(Phosphosites).filter(Phosphosites.ID_PH==phosphosite_name).all()
    protein_name = None
    if form.validate_on_submit():
        protein_name = form.protein_name.data
        return redirect(url_for('phosphositesearchprot', phosphosite_search=protein_name))
    return render_template('phosphositepage.html', form=form, ID_PH=phosphosite_name, GENE=searchphos.GENE, PROTEIN=searchphos.PROTEIN, HU_CHR_LOC=searchphos.HU_CHR_LOC, MOD_RSD=searchphos.MOD_RSD, MW_kD=searchphos.MW_kD, SITE_7_AA=searchphos.SITE_7_AA, DOMAIN=searchphos.DOMAIN, SOURCE=searchphos.SOURCE, searchphoskin=searchphoskin, searchphosdis=searchphosdis )

#Inhibitor page
@application.route('/inh/redirect/<inhibitor_name>', methods=['GET', 'POST'])
def inhibitor(inhibitor_name):
    form = SearchForm()
    searchinh = session.query(Inhibitors).filter(Inhibitors.Inhibitor==inhibitor_name).first()
    searchinhkin = session.query(HumanKinases).join(InhibKin).join(Inhibitors).filter(Inhibitors.Inhibitor==inhibitor_name).all()
    protein_name = None
    if form.validate_on_submit():
        protein_name = form.protein_name.data
        return redirect(url_for('inhibitorsearch', inhibitor_search=protein_name))
    return render_template('inhibitorpage.html', Inhibitor=inhibitor_name, Ki_nM=searchinh.Ki_nM, IC50_nM=searchinh.IC50_nM, Kd_nM=searchinh.EC50_nM, Source=searchinh.Source, IMG_URL=searchinh.IMG_URL, searchinhkin=searchinhkin, form=form)

#--------------------------------------------------------------------------------------------------------------------------  


#--------------------------------------------------------------------------------------------------------------------------  
if __name__ == '__main__':
    app.run()


